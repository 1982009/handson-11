
const Post = () => {
  return (
    <div>Postct Page</div>
  )
}

export default Post